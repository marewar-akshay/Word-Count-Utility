package wordCount.visitors;

import wordCount.dsForStrings.*;

public interface Visitor {
	public void visit(BST bst);
	
}
